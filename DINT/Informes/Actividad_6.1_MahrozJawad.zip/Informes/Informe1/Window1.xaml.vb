﻿Class Window1

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        ReportViewer.Owner = Me

        Dim informe As New CrystalReport5

        informe.SetDatabaseLogon("administrador", "admin123.")

        ReportViewer.ViewerCore.ReportSource = informe



    End Sub
End Class
