
package packUtils;

public class Colores {
    
    public static final String LETRA_NEGRO = (char)27 + "[30m";
    public static final String LETRA_ROJO = (char)27 + "[31m";
    public static final String LETRA_VERDE = (char)27 + "[32m";
    public static final String LETRA_AMARILLO = (char)27 + "[33m";
    public static final String LETRA_AZUL = (char)27 + "[34m";
    public static final String LETRA_MAGENTA = (char)27 + "[35m";
    public static final String LETRA_CYAN = (char)27 + "[36m";
    public static final String LETRA_BLANCO = (char)27 + "[37m";

    public static final String FONDO_BLANCO = (char)27 + "[40m";
    public static final String FONDO_ROJO = (char)27 + "[41m";
    public static final String FONDO_VERDE = (char)27 + "[42m";
    public static final String FONDO_AMARILLO = (char)27 + "[43m";
    public static final String FONDO_AZUL = (char)27 + "[44m";
    public static final String FONDO_MAGENTA = (char)27 + "[45m";
    public static final String FONDO_CYAN = (char)27 + "[46m";
    public static final String FONDO_GRIS = (char)27 + "[47m";

    
    public static final String AZULxAMARILLO = (char)27 + "[34;43m";
    public static final String ROJOxAMARILLO = (char)27 + "[31;43m";

}
