package ejercicio2;

import com.csvreader.CsvWriter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonWriter;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriterFactory;
import javax.json.stream.JsonGenerator;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Ejercicio2 {

    public static void main(String[] args) {

        try {
// P1 – Leer y cargar XML en objecto DOM
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            dbFactory.setIgnoringComments(true);
            dbFactory.setIgnoringElementContentWhitespace(true);
            File inputFile = new File("./datos/deportes.xml");
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
// normalize – elimina nodos vacíos, y une nodos de texto adyacentes
// pero que estaban separados por intros
// P2 – Recorrer DOM mostrando elementos
            System.out.println("Elemento base : " + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("item");
            System.out.println();

            JsonObjectBuilder jObjectPrimero = Json.createObjectBuilder();
            JsonArrayBuilder jAarrySegundo = Json.createArrayBuilder();
            JsonObjectBuilder jObjectTercero = Json.createObjectBuilder();
            JsonArrayBuilder jArrayCategorias = Json.createArrayBuilder();

            int indexCat = 0;
            for (int tabla = 0; tabla < nList.getLength(); tabla++) {
                Node nNodeCampo = nList.item(tabla);
                if (nNodeCampo.getNodeType() == Node.ELEMENT_NODE) {
                    Element elemCampo = (Element) nNodeCampo;
                    Element titulo = (Element) elemCampo.getElementsByTagName("title").item(0);
                    Element link = (Element) elemCampo.getElementsByTagName("link").item(0);
                    //Cogiendo url de la imagen no me funciona.
                    Element imagen = (Element) elemCampo.getElementsByTagName("imagen").item(0).getChildNodes().item("url");
                    ArrayList<String> categoriasArrayList = new ArrayList<String>();
                    NodeList catList = doc.getElementsByTagName("category");
                    for (int i = 0; i < catList.getLength(); i++) {
                        Node nNodeCat = nList.item(indexCat);
                        if (nNodeCat.getNodeType() == Node.ELEMENT_NODE) {
                            Element elemCat = (Element) nNodeCampo;
                            categoriasArrayList.add(elemCat.getTextContent());
                            jArrayCategorias.add(elemCat.getTextContent());
                        }
                    }
                    /**
                     * ******************************
                     */
                    /*Parte CSV*/
        String outputFile = "./datos/users.csv";
// Antes de abrir el fichero comprobamos si existe
        boolean alreadyExists = new File(outputFile).exists();
        try {
            CsvWriter csvOutput = new CsvWriter(new FileWriter(outputFile, true), '|');
            csvOutput.setDelimiter('|'); // No sería necesario porque ya se le ha indicado
            csvOutput.setRecordDelimiter('\n'); // Es el valor por defecto
// Si ya existe el fichero no se necesita escrbir las cabeceras
            if (!alreadyExists) {
                csvOutput.write("titular");
                csvOutput.write("link");
                csvOutput.write("Categoria");
                csvOutput.write("Imagen");
                csvOutput.endRecord();
            }
// ELSE asume que como ya existe tiene las cabeceras
// Escribe unos registros
            
                csvOutput.write(titulo.getTextContent());
                csvOutput.write(link.getTextContent());
                
                for (int i = 0; i < categoriasArrayList.size(); i++) {
                csvOutput.write(categoriasArrayList.get(i));
                    if (i != categoriasArrayList.size()) {
                        csvOutput.write(", ");
                    }
            }
                csvOutput.write(imagen.getTextContent());
                csvOutput.endRecord();

            csvOutput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    

    /**
     * ******************************
     */
    jObjectTercero.add (

    "Title", titulo.getTextContent());
    jObjectTercero.add (

    "link", link.getNodeValue());
    jObjectTercero.add (

    "Title", jArrayCategorias);

    jAarrySegundo.add (/*"Noticias"*/jObjectTercero);
    indexCat  = 0;
}
}
            jObjectPrimero.add("Noticias", jAarrySegundo);
            //Error en arary.
            javax.json.JsonObject jMain = jObjectPrimero.build();

            Gson gson = new GsonBuilder().setPrettyPrinting().create();

            String jsonPrettyPrint = gson.toJson(jMain);
            
            BufferedWriter bw = new BufferedWriter(new FileWriter("./datos/noticias.json"));
            bw.write(jsonPrettyPrint);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
