
package ejercicio1;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="marca")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"id", "modelo"})
class Marca {
    
    @XmlAttribute(name="id")
    private String id;
    
    @XmlElement(name="modelo")
    private ArrayList<Modelo> modelo = new ArrayList<Modelo>();

    public Marca(String id) {
        this.id = id;
    }

    public Marca() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<Modelo> getModelo() {
        return modelo;
    }

    public void setModelo(ArrayList<Modelo> modelo) {
        this.modelo = modelo;
    }

    
    
}
