
package ejercicio1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="modelo")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"mod", "motor", "precio"})
class Modelo {
    
    @XmlAttribute(name="mod")
    private String mod;
    @XmlElement(name="motor")
    private String motor;
    @XmlElement(name="precio")
    private String precio;

    public Modelo() {
    }

    public Modelo(String mod, String motor, String precio) {
        this.mod = mod;
        this.motor = motor;
        this.precio = precio;
    }

    public String getMod() {
        return mod;
    }

    public void setMod(String mod) {
        this.mod = mod;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
    
    
}
