
package ejercicio1;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="coches")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder={"marca"})
public class Coches {
    
    @XmlElement(name="marca")
    private ArrayList<Marca> marca = new ArrayList<Marca>();

    public Coches() {
    }

    public ArrayList<Marca> getMarca() {
        return marca;
    }

    public void setMarca(ArrayList<Marca> marca) {
        this.marca = marca;
    }

}
