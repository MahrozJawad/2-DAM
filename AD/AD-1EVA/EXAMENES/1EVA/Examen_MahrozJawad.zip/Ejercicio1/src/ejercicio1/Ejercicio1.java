package ejercicio1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriter;
import javax.json.JsonWriterFactory;
import javax.json.stream.JsonGenerator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class Ejercicio1 {

    public static void main(String[] args) throws JAXBException, FileNotFoundException {

        // P1 - Unmarshaller de XML a libreria de libros
        JAXBContext context = JAXBContext.newInstance(Coches.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        Coches coches = (Coches) unmarshaller.unmarshal(new File("./datos/coches.xml"));
// P2 - Mostrar libros de la librería

        //System.out.println("Nombre: " + libreria.getNombre());
        ArrayList<Marca> TodosCoches = coches.getMarca();

        int index = 0;
        JsonArrayBuilder jsonArrayB = Json.createArrayBuilder();
        for (Marca marca : TodosCoches) {
            JsonObjectBuilder jsonOB = Json.createObjectBuilder();
            jsonOB.add("marca", marca.getId());

            ArrayList<Modelo> listaModelos = marca.getModelo();
// El index no me esta cumpliendo bien.
            jsonOB.add("Modelo", listaModelos.get(index).getMod()); 

            JsonObjectBuilder jsonOBModelo = Json.createObjectBuilder();
            jsonOBModelo.add("Motor", listaModelos.get(index).getMotor());
            jsonOBModelo.add("Precio", listaModelos.get(index).getPrecio());

            jsonOB.add("Modelo", jsonOBModelo);
            jsonArrayB.add(jsonOB);
            index++;
        }
        JsonArray arrayJ = jsonArrayB.build();

        JsonWriterFactory jsonFactory = Json.createWriterFactory(
                Collections.singletonMap(JsonGenerator.PRETTY_PRINTING, true)
        );
        JsonWriter jsonW
                = jsonFactory.createWriter(
                        new FileOutputStream("./datos/salida.json")
                );
        jsonW.writeArray(arrayJ);
        jsonW.close();
        //System.out.println(lib.getIsbn() + " - " + lib.getTitulo() + " - " + lib.getAutor());
    }
}
