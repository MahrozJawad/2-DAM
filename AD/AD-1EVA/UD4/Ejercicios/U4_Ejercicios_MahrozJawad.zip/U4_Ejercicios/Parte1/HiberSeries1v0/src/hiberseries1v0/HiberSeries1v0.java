package hiberseries1v0;

import packUtils.Menu;


public class HiberSeries1v0 {


    // ***************************************************
    // MAIN
    // ***************************************************
    public static void main(String[] args) {

        Menu.Mostrar();

    }

}
