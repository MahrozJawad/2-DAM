
package librosapp;

import com.dam.bibliotecah.Libros;


public class LibrosApp {

    public static void main(String[] args) {
        Libros libro = new Libros(1, "Macbeth", "William Shakespeare");
System.out.println(libro.toString());
    }
}
