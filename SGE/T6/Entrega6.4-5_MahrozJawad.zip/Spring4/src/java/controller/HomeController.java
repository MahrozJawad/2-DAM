
package controller;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class HomeController {

    @RequestMapping("home.htm")
    public ModelAndView home(HttpServletRequest request) {
        
        ModelAndView mav = new ModelAndView();
        mav.setViewName("home");
        String id = request.getParameter("id");
        String nombre = request.getParameter("nombre");
        mav.addObject("id",id);
        mav.addObject("nombre",nombre);
        
        return mav;
    }
    
    @RequestMapping("contacto.htm")
    public ModelAndView contacto() {
        
        ModelAndView mav = new ModelAndView();
        mav.setViewName("contacto");
        return mav;
    }
}
